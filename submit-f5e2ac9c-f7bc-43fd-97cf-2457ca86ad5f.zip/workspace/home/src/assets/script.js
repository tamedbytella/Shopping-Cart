/* Create an array named products which you will use to add all of your product object literals that you create in the next step. */
const products = [];

/* Create 3 or more product objects using object literal notation */
products.push(
  {
      name: "Cherry",
      price: 4,
      quantity: 0,
      productId: 1001,
      image: "images/cherry.jpg"
  },
  {
      name: "Strawberry",
      price: 5,
      quantity: 0,
      productId: 1002,
      image: "images/strawberry.jpg"
  },
  {
      name: "Orange",
      price: 10,
      quantity: 0,
      productId: 1003,
      image: "images/orange.jpg"
  }
);

/* Declare an empty array named cart to hold the items in the cart */
let cart = [];

/* Create a function named addProductToCart that takes in the product productId as an argument */
function addProductToCart(productId) {
  let product = products.find(p => p.productId === productId);

  if (product) {
      product.quantity += 1;
      let cartProduct = cart.find(p => p.productId === productId);

      if (!cartProduct) {
          cart.push(product);
      }
  }
}

/* Create a function named increaseQuantity that takes in the productId as an argument */
function increaseQuantity(productId) {
  let product = cart.find(p => p.productId === productId);

  if (product) {
      product.quantity += 1;
  }
}

/* Create a function named decreaseQuantity that takes in the productId as an argument */
function decreaseQuantity(productId) {
  let productIndex = cart.findIndex(p => p.productId === productId);

  if (productIndex !== -1) {
    cart[productIndex].quantity -= 1;
    if (cart[productIndex].quantity <= 0) {
      cart.splice(productIndex, 1); // Remove product if quantity is 0 or less
    }
  }
}
/* Create a function named removeProductFromCart that takes in the productId as an argument */
function removeProductFromCart(productId) {
  let productIndex = cart.findIndex(p => p.productId === productId);
  
  if (productIndex !== -1) {
    // Set the quantity to 0 before removing the product
    cart[productIndex].quantity = 0;
    cart.splice(productIndex, 1);
  }
}


/* Create a function named cartTotal that has no parameters */
function cartTotal() {
  return cart.reduce((total, product) => {
    return total + (product.price * product.quantity);
  }, 0);
}

/* Create a function called emptyCart that empties the products from the cart */
function emptyCart() {
  cart.forEach(product => product.quantity = 0);
  cart = [];
}

/* Create a function named pay that takes in an amount as an argument */
let totalPaid = 0;

function pay(amount) {
  totalPaid += amount;
  let total = cartTotal();
  let change = totalPaid - total;

  if (change >= 0) {
      totalPaid = 0;
  }

  return change;
}

/* The following is for running unit tests. */
module.exports = {
  products,
  cart,
  addProductToCart,
  increaseQuantity,
  decreaseQuantity,
  removeProductFromCart,
  cartTotal,
  pay, 
  emptyCart,
}


